#!/usr/bin/env python
# -*- coding: utf-8 -*-

import gtk

window = gtk.Window()
label = gtk.Label("Olá GTK")
window.add(label)
window.set_default_size(150,100)
window.show_all()

gtk.main()
