#!/usr/bin/env python
# -*- coding: utf-8 -*-
###################################
#      _______     ______         #  
#     |_   _\ \   / / ___|        #
#       | |  \ \ / /\___ \        #
#       | |   \ V /  ___) |       #
#       |_|    \_/  |____/        #
#                                 #
###################################
#         TVS DClone Tool         #
#      Version				1.0	    #
#	  By: Teske Virtual Systems    #
#	  This tool is release under   #
#     GPL license, for more       #
#   details see license.txt file  #
###################################
#    http://www.teske.net.br      #
###################################



import commands
import subprocess
import re
import threading
import signal
import signal
import sys
import os
import gtk

import time
import urllib
import cgi

from simplejson import dumps as to_json
from simplejson import loads as from_json

from webgui import start_gtk_thread
from webgui import launch_browser
from webgui import synchronous_gtk_message
from webgui import asynchronous_gtk_message
from webgui import kill_gtk_thread

disks = []


def LoadDisks():
	global disks	
	x = commands.getstatusoutput("gksudo -D \"DClone Tool\" ./utils.sh")
	if x[0] != 0 and x[0] != 256:
		print "Este aplicativo precisa das permissões de administrador para funcionar!"
		label = gtk.Label("Este aplicativo precisa de permissões de administrador para funcionar.")
		dialog = gtk.Dialog("DClone Tool", None, gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT, (gtk.STOCK_OK, gtk.RESPONSE_ACCEPT))
		dialog.vbox.pack_start(label)
		label.show()
		dialog.run()
		dialog.destroy()
		sys.exit(1)
	dk	=	commands.getoutput("sudo ./utils.sh -g")
	
	dk = dk.split(',')
	for disk in dk:
		dsk = commands.getoutput("sudo ./utils.sh -s "+disk)
		model = commands.getoutput("sudo ./utils.sh -m "+disk)
		dsk = dsk.split(' ')
		if	dsk[1] == 'GB':
			dsk[0] = float(dsk[0]) * 1000
		elif	dsk[1] == 'KB':
			dsk[0] = float(dsk[0]) / 1000
		else:
			dsk[0] = float(dsk[0])
		dpk = (disk,dsk[0],model)
		disks.append(dpk)

def buffered(f):
    a = []
    while True:
        c = f.read(1)
        if c == '':
            break
        elif c == '\r':
            yield ''.join(a)
            a = []
        else:
            a.append(c)


class dcfldd:

	LINE_MATCH = re.compile(r'(.*) blocks \((.*)Mb\) written.')
	GROUP_PERCENT, GROUP_TOTALMB, GROUP_BLOCKS, GROUP_MB, GROUP_REMAINING = range(5)

	def __init__(self, diskfrom, diskto, totalsize):
		cmdline = ['/usr/bin/sudo', '/usr/bin/dcfldd', 'if='+diskfrom, 'of='+diskto]
		print "Iniciando copia de "+diskfrom+" para "+diskto+" no total de "+str(totalsize)+" Mb"
		self.process = subprocess.Popen(cmdline, stderr=subprocess.PIPE)
		threading.Thread(target=self.watch, args=[self.process.stderr]).start()
		self.total = totalsize

	def kill(self):
		os.kill(self.process.pid, signal.SIGINT)

	def watch(self, f):
		for line in buffered(f):
			result = self.LINE_MATCH.match(line)
			
			if result:
				result = result.groups()
				blocks, mb = (float(x) for x in result)
				percent = round(( mb /self.total)*100);
				sys.stdout.write('%d Mb / %d Mb (%d%% restantes)\r' % (mb, self.total, percent))
				sys.stdout.flush()

#dcfprocess = dcfldd('/dev/sdb','/dev/null', disks[1][1])

def signal_handler(signal, frame):
	print "Ctrl+C Detectado!"
	dcfprocess.kill()
	sys.exit(0)

class Global(object):
    quit = False
    @classmethod
    def set_quit(cls, *args, **kwargs):
        cls.quit = True

def nl2br(string, is_xhtml= True ):
    if is_xhtml:
        return string.replace('\n','<br />')
    else :
        return string.replace('\n','<br>')

def main():	
	global disks
	global browser
	global web_send
	start_gtk_thread()

	# Create a proper file:// URL pointing to demo.xhtml:
	file = os.path.abspath('page.html')
	uri = 'file://' + urllib.pathname2url(file)
	browser, web_recv, web_send = synchronous_gtk_message(launch_browser)(uri,quit_function=Global.set_quit,echo=False,width=640,height=480)
	browser.connect("navigation-requested", on_navigation_requested)

    # Finally, here is our personalized main loop, 100% friendly
    # with "select" (although I am not using select here)!:
	last_second = time.time()
	uptime_seconds = 1
	clicks = 0
	while not Global.quit:
		'''
		current_time = time.time()
		again = False
		msg = web_recv()
		if msg:
			msg = from_json(msg)
			again = True
        if msg == "got-a-click":
            clicks += 1
            web_send('document.getElementById("messages").innerHTML = %s' %
                     to_json('%d clicks so far' % clicks))
            # If you are using jQuery, you can do this instead:
            # web_send('$("#messages").text(%s)' %
            #          to_json('%d clicks so far' % clicks))

        if current_time - last_second >= 1.0:
            web_send('document.getElementById("uptime-value").innerHTML = %s' %
                     to_json('%d' % uptime_seconds))
            # If you are using jQuery, you can do this instead:
            # web_send('$("#uptime-value").text(%s)'
            #        % to_json('%d' % uptime_seconds))
            uptime_seconds += 1
            last_second += 1.0
		  if again: pass
				  else: 
		'''
		time.sleep(0.1)

def ProcessDiskData(line):
	linedata = line.split(None,6)
	while len(linedata) < 7:
		linedata.append('')
	return linedata

def ProcessType(type):
	return cgi.escape(type.replace('primary',"Primária").replace('extended',"Extendida").replace('logic',"Lógica"))
	
def BuildDiskDataHTML(data,disk):
	diskdata = GetLoadedDiskData(disk)
	base = 'Modelo: '+cgi.escape(diskdata[2])+'<BR>Tamanho total: '+str(diskdata[1])+' MB<BR><center><table width="502" border="0" cellpadding="0" cellspacing="0" style="color: #FFFFFF"> \
	<tr>	\
    <th width="34" height="19" valign="top">ID</td> \
    <th width="93" valign="top">Tamanho</td> \
    <th width="106" valign="top">Tipo</td> \
    <th width="160" valign="top">Sistema de Arquivos </td> \
    <th width="109" valign="top">Sinalizador</td> \
  </tr> '
	dk	=	data.split('\n')
	for line in dk:
		id, inicio, fim, tamanho, tipo, fs, sig = ProcessDiskData(line)
		base += '<tr><td height="19" valign="top"><center>'+id+'</center></td><td valign="top"><center>'+tamanho+'</center></td><td valign="top"><center>'+ ProcessType(tipo)+'</center></td><td valign="top"><center>'+fs.upper()+'</center></td><td valign="top"><center>'+sig+'</center></td></tr>'
	base += '</table></center>'
	return base.replace('\n','')

def GetLoadedDiskData(disk):
	global disks
	for dsk in disks:
		if dsk[0] == disk:
			return dsk
	return (None,None,None)

def on_navigation_requested(view, frame, req, data=None):
	uri = req.get_uri()
	scheme, function, data =uri.split(':', 2)
	if scheme == 'callback':
		if function == '//loaddisks':
			for disk in disks:
				web_send('addDisk(\''+disk[0]+'\',\''+disk[2]+'\');');	
		elif function == '//loaddiskdata':
			data = data.split(':')
			disk_data = commands.getoutput("sudo ./utils.sh -d "+data[1])
			
			#html_data = nl2br(cgi.escape(disk_data))
			html_data = BuildDiskDataHTML(disk_data,data[1])
			if data[0] == 'origem':
				web_send('setDisk(\''+html_data+'\',true)');
			else:
				web_send('setDisk(\''+html_data+'\',false)');
		return True
	else:
		return False

def my_quit_wrapper(fun):
    signal.signal(signal.SIGINT, Global.set_quit)
    def fun2(*args, **kwargs):
        try:
            x = fun(*args, **kwargs) # equivalent to "apply"
        finally:
            kill_gtk_thread()
            Global.set_quit()
        return x
    return fun2


if __name__ == '__main__': # <-- this line is optional
	LoadDisks()
	my_quit_wrapper(main)()


